export class TagsModal {

 LTagsId :number;
 OrganizationId :number;
 TagDescr :string;
 IsActive :boolean;
}

