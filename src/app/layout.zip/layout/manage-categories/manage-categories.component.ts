import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { TagsModal } from './TagsModal';

import {TagsService} from '../../services/tag.service';
import {ActiveModel} from '../../model/ActiveModel';
import {AlertService} from '../../services/alert.service';


@Component({
  selector: 'manage-categories',
  templateUrl: './manage-categories.component.html',
  styleUrls: ['./manage-categories.component.scss']
})
export class ManageCategoriesComponent implements OnInit {
    dtOptions: DataTables.Settings = {};
    groupOptions:{} ;
    organizationId: number;
    tags: TagsModal[];
    organization: string;
    activeModel: ActiveModel[];
    constructor(private httpTagService: TagsService
                , private router: Router
                , private alertService: AlertService
    ) {

    }
    ngOnInit(): void {
        this.organization= localStorage.getItem('organizationName');
        this.organizationId =  Number(localStorage.getItem('organizationId'));
        this.bindTagTables();
        this.loadActiveModel();
    }


    bindTagTables(): void {
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 10,
            serverSide: true,
            processing: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.groupOptions = {
                    organizationId:  localStorage.getItem('organizationId'),
                    ltagType: 'Category'
                };
                dataTablesParameters.groupOptions = this.groupOptions;
                this.httpTagService.get(dataTablesParameters).subscribe(resp => {
                        this.tags = resp[0].Data;

                    callback({
                        recordsTotal: resp[0].RecordsTotal,
                        recordsFiltered: resp[0].RecordsFiltered,
                        data: []
                    });

                });
            },
            columns: [{ data: 'TagDescr' },{ data: 'IsActive' } ]
        };
    }

    public  addCategory() {
        localStorage.removeItem('lTagId');

        this.router.navigate(['/category-detail']);
    }

    public goToGroupDetails(id: number) {

        localStorage.setItem('lTagId', id.toString());
        localStorage.setItem('organizationId',this.organizationId.toString());

        this.router.navigate(['category-detail']);

    }

    public goToClientDetails() {
       this.router.navigate(['organization-detail']);
    }
    public  loadActiveModel(){
        this.activeModel = [{"value": 'True' ,"name": 'Active'},{"value": 'False' ,"name": 'InActive'}];
    }


    public onStatusChange(tag: TagsModal, isActive: boolean) {

        this.httpTagService.updateActive(tag.LTagsId, isActive)
            .subscribe(
                data => {
                    if (data) {
                        tag.IsActive = isActive;
                        this.alertService.success(tag.IsActive ? 'category activate successfully' : 'category deactivate successfully' );
                    }
                    else {
                        this.alertService.error('Something wrong please contact to administrator.');
                    }
                },
                error => {
                    this.alertService.error(error);
                });
    }
}
