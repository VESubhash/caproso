export class DocumentsModal {

 DocumentId :number;
 OrganizationId :number;
 DocCaption :string;
 DocPath: string;
 IsActive :boolean;
 File:File;
}

