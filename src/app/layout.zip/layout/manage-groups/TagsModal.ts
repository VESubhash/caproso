export class TagsModal {

 LTagsId :number;
 OrganizationId :number;
 TagDescr :string;
 IsActive :boolean;
}

export class DataTablesResponse {
    data: any[];
    draw: number;
    recordsFiltered: number;
    recordsTotal: number;
}
