export class LtagModel {
    LTagId: number;
    TagName: string;
    TagDescr: string;
    ParentTagId: string;
}
