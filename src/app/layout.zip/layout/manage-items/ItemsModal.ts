export class ItemsModal {

    ItemId :number;
    OrganizationId :number;
    CategoryName: string;
    SubCategoryName: string;
    OrganizationName: string;
    ItemCode: string;
    ItemDescr: string;
    LCategoryId: number;
    LSubCategoryId: number;
    LUnitId: number;
    Unit: string;
    UnitPrice: string;
    IsActive:boolean;
}

