export class ItemSearchModal {
    OrganizationId: string;
    CategoryId :number;
    SubCategoryId :number;
    ItemName :string;

}

