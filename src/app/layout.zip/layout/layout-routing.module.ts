import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'dashboard' },
            { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
            { path: 'charts', loadChildren: './charts/charts.module#ChartsModule' },
            { path: 'manage-users', loadChildren: './manage-user/manage-user.module#ManageUserModule' },
            { path: 'manage-addresses', loadChildren: './manage-addresses/manage-addresses.module#ManageAddressesModule' },
            { path: 'manage-groups', loadChildren: './manage-groups/manage-groups.module#ManageGroupsModule' },
            { path: 'manage-categories', loadChildren: './manage-categories/manage-categories.module#ManageCategoriesModule' },
            { path: 'manage-units', loadChildren: './manage-units/manage-units.module#ManageUnitsModule' },
            { path: 'manage-subcategories', loadChildren: './manage-subcategories/manage-subcategories.module#ManageSubcategoriesModule' },
            { path: 'manage-organizations', loadChildren: './manage-organizations/manage-organizations.module#ManageOrganizationsModule' },
            { path: 'manage-affiliates', loadChildren: './manage-affiliates/manage-affiliates.module#ManageAffiliatesModule' },
            { path: 'manage-items', loadChildren: './manage-items/manage-items.module#ManageItemsModule' },
            { path: 'manage-item', loadChildren: './manage-item/manage-item.module#ManageItemModule' },
            { path: 'manage-clients', loadChildren: './manage-clients/manage-clients.module#ManageClientsModule' },
            { path: 'manage-estimates', loadChildren: './manage-estimates/manage-estimates.module#ManageEstimatesModule' },
            { path: 'manage-documents', loadChildren: './manage-documents/manage-documents.module#ManageDocumentsModule' },
            { path: 'group-detail', loadChildren: './group-detail/group-detail.module#GroupDetailModule' },
            { path: 'category-detail', loadChildren: './category-detail/category-detail.module#CategoryDetailModule' },
            { path: 'unit-detail', loadChildren: './unit-detail/unit-detail.module#UnitDetailModule' },
            { path: 'subcategory-detail', loadChildren: './subcategory-detail/subcategory-detail.module#SubcategoryDetailModule' },
            { path: 'item-detail', loadChildren: './item-detail/item-detail.module#ItemDetailModule' },
            { path: 'address-detail', loadChildren: './address-detail/address-detail.module#AddressDetailModule' },
            { path: 'organization-detail', loadChildren: './organization-detail/organization-detail.module#OrganizationDetailModule' },
            { path: 'affiliate-detail', loadChildren: './affiliate-detail/affiliate-detail.module#AffiliateDetailModule' },
            { path: 'user-detail', loadChildren: './user-detail/user-detail.module#UserDetailModule' },
            { path: 'clients-detail', loadChildren: './clients-detail/clients-detail.module#ClientsDetailModule' },
            { path: 'document-detail', loadChildren: './document-detail/document-detail.module#DocumentDetailModule' },
            { path: 'estimate', loadChildren: './estimate-detail/estimate-detail.module#EstimateDetailModule' },
            { path: 'tables', loadChildren: './tables/tables.module#TablesModule' },
            { path: 'forms', loadChildren: './form/form.module#FormModule' },
            { path: 'bs-element', loadChildren: './bs-element/bs-element.module#BsElementModule' },
            { path: 'grid', loadChildren: './grid/grid.module#GridModule' },
            { path: 'components', loadChildren: './bs-component/bs-component.module#BsComponentModule' },
            { path: 'blank-page', loadChildren: './blank-page/blank-page.module#BlankPageModule' }
        ]
    }
    // ,
    // { component: EstimateDetailComponent,
    //     path: '',
    //     children: [
    //         { path: 'estimate-create', component: EstimateCreateComponent, canActivate: [AuthGuard] },
    //         { path: 'estimate-cbd', component: EstimateCbdComponent, canActivate: [AuthGuard] },
    //
    //     ]
    // }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule {}
