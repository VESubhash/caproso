import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageEstimatesComponent } from './manage-estimates.component';

const routes: Routes = [
    {
        path: '', component: ManageEstimatesComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ManageEstimatesRoutingModule {
}
