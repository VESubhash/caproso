import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import {ActiveModel} from '../../model/ActiveModel';
import {EstimateService} from '../../services/estimate.service';
import {EstimateModel} from '../../model/EstimateModel';
import {ItemsModal} from '../manage-items/ItemsModal';
import {AlertService} from '../../services/alert.service';


@Component({
  selector: 'manage-estimates',
  templateUrl: './manage-estimates.component.html',
  styleUrls: ['./manage-estimates.component.scss']
})
export class ManageEstimatesComponent implements OnInit {
    dtOptions: DataTables.Settings = {};
    estimateOptions:{} ;
    organizationId: number;
    estimates: EstimateModel[];
    organization: string;
    activeModel: ActiveModel[];
    constructor(private httpEstimateService: EstimateService, private router: Router, private alertService: AlertService) {

    }
    ngOnInit(): void {
        this.organization= localStorage.getItem('organizationName');
        this.organizationId =  Number(localStorage.getItem('organizationId'));
        this.bindEstimateTables();

    }


    bindEstimateTables(): void {
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 10,
            serverSide: true,
            processing: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.estimateOptions = {
                    organizationId:  localStorage.getItem('organizationId'),
                };
                dataTablesParameters.estimateOptions = this.estimateOptions;
                this.httpEstimateService.get(dataTablesParameters).subscribe(resp => {
                        this.estimates = resp[0].Data;

                    callback({
                        recordsTotal: resp[0].RecordsTotal,
                        recordsFiltered: resp[0].RecordsFiltered,
                        data: []
                    });

                });
            },
            columns: [{ data: 'EstimateNumber' },{ data: 'EstimateTitle' },{ data: 'CbdTitle' },{ data: 'EstimateGroupName' },{data: 'ManagerName'}, { data: 'IsActive' } ]
        };
    }

    public onStatusChange(estimate: EstimateModel, isActive: boolean) {

        this.httpEstimateService.updateActive(estimate.EstimateId, isActive)
            .subscribe(
                data => {
                    if (data) {
                        estimate.IsActive = isActive;
                        this.alertService.success(estimate.IsActive ? 'Estimate activate successfully' : 'Estimate deactivate successfully' );
                    }
                    else {
                        this.alertService.error('Something wrong please contact to administrator.');
                    }
                },
                error => {
                    this.alertService.error(error);
                });
    }

    public  addEstimate() {
        localStorage.removeItem('estimateId');

        this.router.navigate(['estimate/create']);
    }

    public goToEstimateDetail(id: number) {
        localStorage.removeItem('estimator');
        localStorage.setItem('estimateId', id.toString());
        localStorage.setItem('organizationId',this.organizationId.toString());

       // window.location.reload(true);
        //this.router.navigate(['estimate/item']);
        window.location.href = 'estimate/item';

    }
    public goToEstimateDetailEdit(id: number) {
        localStorage.removeItem('estimator');
        localStorage.setItem('estimateId', id.toString());
        localStorage.setItem('organizationId',this.organizationId.toString());

       this.router.navigate(['estimate/create']);


    }


}
