export class Golfball {
  constructor(
    public stage: string,
    public label: string,
    public complete: boolean,
    public current: boolean
  ) {

  }
}
