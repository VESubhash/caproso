export class ChildDetailsModel {

  constructor(public name: string,
              public age: number,
              public imageUrl: string
              ) {}

}

