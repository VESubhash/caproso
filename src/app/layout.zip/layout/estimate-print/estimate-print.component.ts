import {Component, OnInit} from '@angular/core';
import {EstimatedItemsModel} from '../../model/EstimatedItemsModel';
import {Router} from '@angular/router';
import {EstimateService} from '../../services/estimate.service';
import {AlertService} from '../../services/alert.service';
import {EstimateModel} from '../../model/EstimateModel';
import {EstimateMarkupsModel} from '../../model/EstimateMarkupsModel';

@Component({
    selector: 'estimate-documents',
    templateUrl: './estimate-print.component.html',
    styleUrls: ['./estimate-print.component.scss']
})
export class EstimatePrintComponent implements OnInit {
    estimatedItems: EstimatedItemsModel[] = [];
    estimateItemOptions: {};
    dataTablesParameters: any;
    estimateId: number;
    estimateModel: EstimateModel;
    estimateMarkups: EstimateMarkupsModel[] = [];
    totalCost: number;
    constructor( private router: Router,
                 private alertService: AlertService,
                 private httpEstimateService: EstimateService,
    ) {
    }

    ngOnInit() {
        this.estimateId =   Number(localStorage.getItem('estimateId'));
        this.estimateModel= {
            EstimateTitle:'',
            EstimateNumber:'',
            EstimateId:0,
            ManagerName:'',
            ManagerId:0,
            EstimateGroupName:'',
            Assumptions:'',
            ProjectScope:'',
            CbdTitle:'',
            EstimateGroupId:0,
            IsActive:true,
            ModifiedById:0,
            OrganizationId:0,
            Estimator:'',

        }
        if (this.estimateId > 0 ) {

            this.getEstimateDetail(this.estimateId);

        }

        this.getEstimatedItem();
        this.getEstimateMarkups();
    }

    print(): void {
        let printContents, popupWin;
        printContents = document.getElementById('print-section').innerHTML;
        popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
        popupWin.document.open();
        popupWin.document.write(`
      <html>
        <head>
          <title>Print tab</title>
          <style>
         @media print {
               body
                 {
                 font-family: Arial;
                 font-size:14px;
                 }    
    
                .table{
                border: 1px #ccc solid;
                width:100%;
                }
                 .odd{
                 background-color: #00b3ee;
                 }
               }   
          //........Customized style.......
          </style>
        </head>
    <body onload="window.print();window.close()">${printContents}</body>
      </html>`
        );
        popupWin.document.close();
    }

    public  getEstimateDetail(estimateId){
        this.httpEstimateService.getEstimateDetail(estimateId, true)
            .subscribe((data:any) => {
                localStorage.setItem('cbdTitle', data.CbdTitle);
                this.estimateModel = data;
                // this.estimateCreateForm.patchValue({
                //     OrganizationId: data.organizationId,
                //     EstimateId: data.EstimateId,
                //     EstimateTitle: data.EstimateTitle,
                //     EstimateNumber: data.EstimateNumber,
                //     ProjectScope: data.ProjectScope,
                //     Assumptions: data.Assumptions,
                //     ManagerId: data.ManagerId,
                //     EstimateGroupId: data.EstimateGroupId,
                // });
            });
    }

    public getEstimatedItem() {
        this.estimateItemOptions = {
            estimateId: localStorage.getItem('estimateId'),

        };
        this.dataTablesParameters = this.estimateItemOptions;
        this.httpEstimateService.getEstimateItemList(this.dataTablesParameters).subscribe(resp => {
            this.estimatedItems = resp[0].Data;
            this.totalCost =  Number(resp[0].Data.reduce((sum, val) => sum + val.TotalCost, 0));

        });


    }

    public getEstimateMarkups(){
        this.httpEstimateService.getEstimateMarkup(this.estimateId)
            .subscribe(
                (data :EstimateMarkupsModel[])=> {
                    this.estimateMarkups = data;
                },
                error => {
                    this.alertService.error(error);

                });
    }
}
