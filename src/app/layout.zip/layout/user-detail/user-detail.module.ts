import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbCarouselModule, NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { StatModule } from '../../shared';

import { UserDetailComponent } from './user-detail.component';
import { UserDetailRoutingModule } from './user-detail-routing.module';
import { AddressComponent } from '../Shared/address/address.component'



@NgModule({
    imports: [
        CommonModule,
        NgbCarouselModule.forRoot(),
        NgbAlertModule.forRoot(),
        UserDetailRoutingModule,
        StatModule,
        DataTablesModule,
        ReactiveFormsModule

    ],
    declarations: [UserDetailComponent, AddressComponent

    ]
})
export class UserDetailModule {}



