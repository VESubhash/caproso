export class ClientsModal {

    UserId: number;
    OrganizationId: number;
    OrganizationName: string;
    UserName: string;
    FirstName: string;
    LastName: string;
    IsActive: boolean;
    UserRoleId: number;
    UserRoleName: string;
    UserGroupName: string;
    StatusId: number;
    CreatedDate: Date;
}

export class DataTablesResponse {
    data: any[];
    draw: number;
    recordsFiltered: number;
    recordsTotal: number;
}
