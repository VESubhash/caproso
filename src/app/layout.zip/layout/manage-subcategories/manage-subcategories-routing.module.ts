import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageSubcategoriesComponent } from './manage-subcategories.component';

const routes: Routes = [
    {
        path: '', component: ManageSubcategoriesComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ManageSubcategoriesRoutingModule {
}
