export class AffiliatesModal {

    UserId: number;
    AffiliateId: number;
    AffiliateName: string;
    UserName: string;
    FirstName: string;
    LastName: string;
    IsActive: boolean;
    UserRoleId: number;
    UserRoleName: string;
    UserGroupName: string;
    CreatedDate: Date;
}

// export class DataTablesResponse {
//     data: any[];
//     draw: number;
//     recordsFiltered: number;
//     recordsTotal: number;
// }
